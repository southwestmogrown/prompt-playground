# Design System Document: Luminous Refraction

## 1. Overview & Creative North Star: "The Digital Prism"
This design system is anchored by the Creative North Star of **"The Digital Prism."** We are moving away from the static, flat-file nature of traditional web design toward an experience that feels like light passing through a high-end lens. The interface should feel alive—luminous, warm, and perpetually refracting.

To achieve this "High-End Editorial" feel, we reject the rigid, boxy constraints of standard UI. Instead, we utilize **intentional asymmetry**, overlapping glass layers, and a sophisticated interplay between warm sunset tones and ethereal cool accents. We do not just "display" content; we curate it within a space that feels like it’s made of captured light and frosted crystal.

---

## 2. Colors & Surface Philosophy
Our palette is a curated spectrum of warmth, avoiding the clinical "coldness" of traditional tech grays and deep blues.

### The Color Logic
- **Primary & Secondary (Sunset Core):** Using `primary` (#a83028) and `secondary` (#7b5400) provides the foundation of coral and amber. These are used for moments of high energy and brand intent.
- **Tertiary (Ethereal Counterpoint):** The `tertiary` (#006760) introduces a sophisticated teal, acting as the "refracted" light that balances the warmth.
- **The "No-Line" Rule:** We explicitly prohibit 1px solid borders for sectioning. Definition is achieved through background shifts. For example, a `surface-container-low` section should sit against a `surface` background to create a boundary without a "line."

### Surface Hierarchy & Glassmorphism
The UI is a series of stacked, physical layers. 
- **The Glass & Gradient Rule:** Floating elements (Modals, Navigation Bars, Featured Cards) must utilize Glassmorphism. Use semi-transparent `surface` colors with a `backdrop-filter: blur(20px)`. 
- **Signature Textures:** Main CTAs and Hero sections should use a linear gradient transitioning from `primary` (#a83028) to `primary-container` (#ff7668) at a 135-degree angle to mimic the flow of light.

---

## 3. Typography: Editorial Sophistication
We pair the geometric precision of **Manrope** for high-impact displays with the timeless readability of **Inter** for functional content.

- **Display & Headlines (Manrope):** These should be treated as graphic elements. Use `display-lg` (3.5rem) with `-0.02em` tracking to create a tight, authoritative editorial look.
- **Body & Labels (Inter):** Use `body-lg` (1rem) with generous tracking (`0.015em`) to allow the layout to "breathe."
- **Visual Hierarchy:** Large scale contrasts are encouraged. A `display-md` headline paired directly with a `label-md` creates a "High-Fashion" typographic tension that feels premium and intentional.

---

## 4. Elevation & Depth: Tonal Layering
Depth in this system is a result of light physics, not drop-shadow presets.

- **The Layering Principle:** Stacking `surface-container` tiers creates a soft, natural lift. Place a `surface-container-lowest` card on a `surface-container-low` background. The subtle 2-3% shift in luminosity is all the "border" you need.
- **Ambient Shadows:** When a floating effect is required (e.g., a "Prism" card), use extra-diffused shadows.
    - **Token:** `shadow-ambient`
    - **Values:** 0px 20px 40px rgba(48, 46, 43, 0.06) (using a tinted version of `on-surface`).
- **The Ghost Border:** If accessibility requires a container edge, use a "Ghost Border": `outline-variant` (#b1aca8) at 15% opacity.
- **Light Refraction (Glows):** For active states, apply a 2px inner-glow using `primary-fixed` (#ff7668) with a 40% opacity to simulate light being trapped within the glass edge.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary-container`). Roundedness: `xl` (1.5rem). No border. White text (`on-primary`).
- **Secondary:** Glass-filled. `surface-container-highest` at 60% opacity with a `backdrop-blur`. 
- **Tertiary:** Ghost style. No background, `label-md` typography, `primary` color text.

### Cards & Lists
- **The Forbid Rule:** No horizontal dividers. Separate list items using 16px of vertical white space or alternating subtle shifts between `surface-container-low` and `surface-container-lowest`.
- **The Card:** Use `ROUND_SIXTEEN` (1rem) for all corners. Apply a subtle 1px "Ghost Border" to the top and left edges only to simulate a light source hitting the "edge" of the prism.

### Input Fields
- **Styling:** Soft `surface-container-high` backgrounds. 
- **States:** On focus, the background shifts to `surface-container-lowest` and an animated "glow" border in `tertiary` (#006760) fades in at 30% opacity.

### Signature Component: The "Refraction Mesh"
A background decorative element using blurred blobs of `primary_container`, `secondary_container`, and `tertiary_container`. These should sit behind glass layers to provide the "vibrant, high-energy" atmosphere requested.

---

## 6. Do’s and Don’ts

### Do:
- **Do** use overlapping elements. Let a glass card partially obscure a background gradient to show off the blur effect.
- **Do** use generous white space. High-end design requires room to breathe.
- **Do** use "Warm" neutrals. Use `surface` (#fbf5f0) instead of pure white or cool grays.

### Don't:
- **Don't** use 1px solid black or dark gray borders. It breaks the "Luminous" illusion.
- **Don't** use standard "Drop Shadows." They feel heavy and "pasted on." Use tonal layering instead.
- **Don't** use "Cold" blues. If a blue is needed, lean into the `tertiary` teal spectrum to maintain the sunset warmth.
- **Don't** crowd the interface. If the UI feels busy, increase the tracking on your typography and the padding in your containers.