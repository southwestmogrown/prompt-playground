```markdown
# Design System Document: Luminous Refraction

## 1. Overview & Creative North Star: "The Ethereal Editor"
This design system moves away from the sterile, rigid constraints of traditional SaaS interfaces toward a "Luminous Refraction" aesthetic. Our Creative North Star is **The Ethereal Editor**—a philosophy that treats the screen not as a flat canvas, but as an optical lens. 

We achieve a high-end, bespoke feel by rejecting standard borders and harsh shadows in favor of light-bending glassmorphism, warm organic tones, and intentional asymmetry. The layout should feel "grown" rather than "built," utilizing overlapping layers of frosted surfaces that catch the light of ambient "sunset" gradients. This is a system of depth, warmth, and atmospheric clarity.

---

## 2. Colors & Surface Language
The palette is rooted in a warm, tactile cream (`#FDFBF7`), avoiding the clinical coldness of pure white.

### Color Roles
*   **Base Surface:** `surface` (#f8f6f2) serves as our foundational "paper."
*   **The Sunset Spectrum:** Use `primary` (Coral/Amber), `secondary` (Violet/Lavender), and `tertiary` (Gold) for ambient background orbs. These should never be used as flat blocks of color but as blurred, low-opacity radial gradients that sit behind the glass layers.
*   **On-Surface Typography:** Use `on_surface` (#2e2f2d) for high-contrast headers. Avoid pure black; this deep charcoal maintains the "ink on cream" editorial feel.

### The "No-Line" Rule
**Explicit Instruction:** Prohibit the use of 1px solid borders for sectioning. Boundaries must be defined through:
1.  **Background Shifts:** Transitioning from `surface` to `surface_container_low`.
2.  **Tonal Transitions:** Using subtle `surface_variant` backgrounds.
3.  **Refraction:** Let the `backdrop-blur` of a glass element define its own edge against the sunset gradients.

### The Glass & Gradient Rule
All floating interface elements must utilize **Hyper-Glassmorphism**.
*   **Fill:** 60–80% opacity of `surface_container_lowest`.
*   **Blur:** Minimum `20px` backdrop-blur.
*   **Signature Texture:** Primary CTAs should use a linear gradient from `primary` to `primary_container` (Coral to Sunset Orange) to provide a "soulful" glow that feels alive.

---

## 3. Typography: Editorial Authority
We pair the geometric confidence of **Manrope** with the functional clarity of **Inter**.

*   **Display & Headlines (Manrope):** Set in Extra Bold with tight letter-spacing (-0.02em). This creates a "heavy" editorial anchor against the "light" glass components. Use `display-lg` for hero moments to command attention.
*   **Body & Titles (Inter):** Focused on readability. Use `body-lg` for primary narrative text. The juxtaposition of a thick, serif-like geometric header against a clean Swiss-style body font creates a premium, high-fashion aesthetic.
*   **Hierarchy:** Use scale, not just weight. A `headline-lg` in `on_surface` next to a `body-md` in `on_surface_variant` creates depth without needing decorative elements.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are forbidden. We use "Refractive Elevation."

*   **The Layering Principle:** Stack containers to create depth. A `surface_container_lowest` glass card should sit atop a `surface_container_low` section.
*   **Refractive Shadows:** When an element must float (e.g., a modal or primary card), use a diffused shadow (Blur: 30px+) at 8% opacity. The shadow color must be a tinted version of the `primary` or `secondary` token (e.g., a faint coral glow) to simulate light passing through a prism.
*   **The Ghost Border:** For high-contrast accessibility, use a "Ghost Border": a 1px stroke using `outline_variant` at **10-15% opacity**. It should feel like a catch-light on the edge of a glass pane, not a container line.
*   **Internal Glow:** Apply a 1px inner-shadow/glow of `surface_container_lowest` (pure cream-glass) at the top edge of cards to simulate a beveled glass edge.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary_container`). `xl` roundedness. No border. Text is `on_primary`.
*   **Secondary (Glass):** `surface_container_lowest` at 40% opacity, 20px blur, with a 15% `outline_variant` ghost border.
*   **Tertiary:** Bold `on_surface` text with a subtle `primary` underline that expands on hover.

### Cards & Containers
*   **Hyper-Glass Style:** Cards must never use dividers. Use vertical whitespace (`spacing-xl`) and `surface_container` shifts to separate content. 
*   **Refraction:** If a card sits over a sunset gradient, the gradient colors must bleed through the backdrop-blur.

### Input Fields
*   **Soft Focus:** Use `surface_container_low` for the field background. On focus, transition the "Ghost Border" to 40% opacity of the `primary` color and increase the backdrop-blur of the field itself.

### Selection Elements (Chips & Radio)
*   **Chips:** Pill-shaped (`full` roundedness). Unselected: Glass. Selected: `secondary_container` with `on_secondary_container` text.
*   **Checkboxes:** Avoid square boxes. Use a custom "Refractive Circle" that fills with a gradient when active.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** embrace negative space. Let the warm cream `surface` breathe.
*   **Do** overlap elements. A glass card should slightly overlap a header or a gradient orb to prove its translucency.
*   **Do** use asymmetrical layouts. Align text to the left but offset images or glass cards to create a dynamic, editorial rhythm.

### Don’t:
*   **Don’t** use 100% opaque borders. They break the "Luminous Refraction" illusion.
*   **Don’t** use pure #000000 or #FFFFFF. Use the `on_surface` and `surface_container_lowest` tokens.
*   **Don’t** use standard grey shadows. Shadows should feel like "dark light" or tinted refraction.
*   **Don’t** use dividers. If you feel the need for a line, use a 24px gap instead.```